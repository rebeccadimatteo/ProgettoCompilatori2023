package esercitazione5.visitor;

//interfaccia che uso per dire ad una classe che è visitabile
public interface Visitable {
    Object accept(Visitor v) throws Exception;
}
