package esercitazione5.visitor.semanticVisitor;


import esercitazione5.nodi_Gram.FunOp;
import esercitazione5.nodi_Gram.*;
import esercitazione5.nodi_Gram.ProgramOp;
import esercitazione5.nodi_Gram.VarDeclOp;
import esercitazione5.nodi_Gram.nodiExpr.*;
import esercitazione5.nodi_Gram.nodiExpr.Identifier;
import esercitazione5.nodi_Gram.statement.*;
import esercitazione5.table.FieldType;
import esercitazione5.table.SymbolTable;
import esercitazione5.table.TableRow;
import esercitazione5.utils.Eccezioni;
import esercitazione5.visitor.Visitor;

import java.util.ArrayList;

/**
 *  Si occupa della generazione degli scope
 */
public class SemanticVisitorType implements Visitor {

    private SymbolTable currentScope;

    private static final String[][] combinazioniAritOp= { {"integer", "integer", "integer"},
            {"integer", "float", "float"},
            {"float", "integer", "float"},
            {"float", "float", "float"} };

    private static final String[][] combinazioniStrOp= { {"string", "string", "string"},
            {"string", "float","string"},
            {"string","integer","string"},
            {"string", "char", "string"},
            {"integer","string","string"},
            {"float","string","string"},
            {"char","string","string"}};

    private static final String[][] combinazioniBooleanOp= { {"boolean", "boolean", "boolean"} };

    private static final String[][] combinazioniRelOp= { {"integer", "integer", "boolean"},
            {"integer", "float", "boolean"},
            {"float", "integer", "boolean"},
            {"float", "float", "boolean"},
            {"string","string","boolean"},
            {"char","char","boolean"}};

    private static final String[][] combinazioniMinus= { {"integer", "integer"},
            {"float", "float"} };


    private static final String[][] combinazioniNot= { {"boolean", "boolean"} };

    private static final String[][] compatibilita= {{"integer","integer"},
            {"float","float"},
            {"float","integer"},
            {"char","char"},
            {"string","string"},
            {"boolean","boolean"},
            {"void","void"}};


    @Override
    public Object visit(ProgramOp programOp) throws Exception {

        currentScope=programOp.getSymbolTable();
        if(programOp.getVarDeclList()!=null){
            for (VarDeclOp var: programOp.getVarDeclList())
                var.accept(this);
        }


        if(programOp.getFunOpList()!=null){
            for(FunOp fun: programOp.getFunOpList())
                fun.accept(this);
        }

        programOp.getMain().accept(this);

        return null;
    }

    @Override
    /**
     *  In questo metodo controllo che il tipo della variabile corrisponde con il valore d'inizializzazione
     */
    public Object visit(VarDeclOp varDecl) throws Exception {
        String identificatore="";
        String tipo="";
        for (Expr expr:varDecl.getExprList()){

            if (expr instanceof IdInitOp){
                identificatore=((IdInitOp) expr).getId().getLessema();
                tipo= (String) expr.accept(this);
                //Controllo se il tipo corrisponde con quello della dichiarazione
                if(!tipo.equals(varDecl.getType())) {
                    throw new Eccezioni.InizializationError();
                }
            }

        }

        return null;
    }

    @Override
    /**
     *  In questo metodo controllo che il return della funzione, e lancio il controllo sul body
     */
    public Object visit(FunOp funOp) throws Exception {


        //Controllo che il return della funzione corrisponde col tipo dichiarato
        String tipoDichiarato=null;
        String tipoRestituito=null;

        TableRow result=currentScope.lookup(funOp.getIdentificatore().getLessema());
        if(result!=null)
            tipoDichiarato=((FieldType.FieldTypeFunction) result.getType()).getOutputParam().get(0);

        for(Statement stm:funOp.getBody().getListStatement()){
            if (stm instanceof ReturnOp){
                currentScope=funOp.getSymbolTable();
                tipoRestituito= (String) stm.accept(this);
                currentScope=funOp.getSymbolTable().getFather();
            }
        }


        if(tipoDichiarato==null)//La funzione non è presente nel type environment
            throw new Eccezioni.NoDeclarationError("Funzione",funOp.getIdentificatore().getLessema());
        if(tipoRestituito==null && !tipoDichiarato.equals("void")) //La funzione non è void ma non possiede un return
            throw new Eccezioni.NoReturnError();
        if(tipoDichiarato.equals("void") && tipoRestituito!=null) //La funzione è void ma restituisce un tipo
            throw new Eccezioni.ReturnError();
        if(!tipoDichiarato.equals("void") && !tipoDichiarato.equals(tipoRestituito))//La funzione non è void ma il tipo restituito non coincide
            throw new Eccezioni.ReturnError();

        //Lancio il controlli nel body
        currentScope=funOp.getSymbolTable();
        funOp.getBody().accept(this);

        currentScope=funOp.getSymbolTable().getFather();
        return null;
    }

    @Override
    public Object visit(ParDeclOp parDeclOp) throws Exception {
        return null;
    }

    @Override
    /**
     *  Lanco il controllo delle variabili e gli statement nel body
     */
    public Object visit(BodyOp bodyOp) throws Exception {

        //Se il body contiene delle variabili, controllo le variabili
        if(bodyOp.getListVar()!=null){
            for(VarDeclOp var:bodyOp.getListVar())
                var.accept(this);
        }

        //Se il bodi contiene degli statement li controllo
        if(bodyOp.getListStatement()!=null){
            for(Statement stm:bodyOp.getListStatement())
                stm.accept(this);
        }

        return null;
    }

    @Override
    public Object visit(AssignOp assignOp) throws Exception {

        ArrayList<Identifier> listaId=assignOp.getListId();
        ArrayList<Expr> listaExpr=assignOp.getListExpr();

        //Verifico che il numero di identificatori coincide con numero di espressioni
        if(listaId.size()==listaExpr.size()){ //Controllo se le due liste hanno la stessa size
            for(int i=0;i<listaId.size();i++){
                String typeId= (String) listaId.get(i).accept(this);
                String typeExpr= (String) listaExpr.get(i).accept(this);
                if(!typeId.equals(typeExpr))
                    throw new Eccezioni.TypeAssignError();
            }
        }else{
            throw new Eccezioni.AssignError();
        }

        return null;
    }

    @Override
    public Object visit(FunCallOpStat callFunOpStat) throws Exception {

        //Verifico che il numero di parametri nella chiamata coincide
        TableRow result=currentScope.lookup(callFunOpStat.getIdentifier().getLessema());
        if(result==null){
            throw new Eccezioni.NoDeclarationError("Funzione",callFunOpStat.getIdentifier().getLessema()); //La funzione non è stata dichairata
        }else{
            ArrayList<String> typeField=((FieldType.FieldTypeFunction) result.getType()).getInputParam();
            String[] typeStream=result.getPropreties().split(",");
            int numeroParamteri=typeField.size();
            int numeroParametriChiamata=0;
            if(callFunOpStat.getListExpr()!=null)
                numeroParametriChiamata=callFunOpStat.getListExpr().size();

            if(numeroParamteri!=numeroParametriChiamata){
                throw new Eccezioni.CallFunNumParamError(); //Il Numero di parametri non coincide
            }else{
                //Verifico che il tipo coincide
                for(int i=0;i<numeroParametriChiamata;i++){
                    Expr expr=(callFunOpStat.getListExpr().get(i));
                    if(!expr.accept(this).equals(typeField.get(i))) {
                        throw new Eccezioni.CallFunTypeParamError();
                    }else{
                        //Aggiungo lo stream
                        if (expr.getMode()==null)
                            expr.setMode(typeStream[i]);

                    }
                }
            }
        }

        return null;
    }

    @Override
    public Object visit(ForOp forOp) throws Exception {

        //Verifico che il limite minimo e massimo (e1 ed e2) sono constanti intere
        String typeE1= (String) forOp.getId().getExpr().accept(this);
        String typeE2=(String) forOp.getCons().accept(this);
        if(!typeE1.equals("integer") | !typeE2.equals("integer"))
            throw new Eccezioni.ForExpressionTypeError();

        //Entro nello scope
        currentScope=forOp.getSymbolTable();
        forOp.getBodyOp().accept(this);
        //Esco dallo scope
        currentScope=forOp.getSymbolTable().getFather();

        return null;
    }

    @Override
    public Object visit(IfStatOp ifStatOp) throws Exception {

        String tipo= (String) ifStatOp.getExpr().accept(this);
        if (!tipo.equals("boolean"))
            throw new Eccezioni.ConditionNotValid();

        //BodyThen
        //Entro nello scope
        currentScope=ifStatOp.getSymbolTableThen();
        ifStatOp.getBodyThen().accept(this);
        //Esco dallo scope
        currentScope=ifStatOp.getSymbolTableThen().getFather();
        //BodyElse
        if(ifStatOp.getBodyElse()!=null) {
            //Entro nello scope
            currentScope=ifStatOp.getSymbolTableElse();
            ifStatOp.getBodyElse().accept(this);
            //Esco dallo sope
            currentScope=ifStatOp.getSymbolTableElse().getFather();
        }
        return null;
    }

    @Override
    public Object visit(ReadOp readOp) throws Exception {

        //Controllo se gli identificatori usati,sono stati dichiarati
        for (Identifier id:readOp.getListId()){
            id.accept(this);
        }
        return null;
    }

    @Override
    /**
     * Restituisco il tipo di return
     */
    public Object visit(ReturnOp returnOp) throws Exception {
        String tipo=null;
        if(returnOp.getExpr()!=null) {
            tipo = (String) returnOp.getExpr().accept(this);
        }

        return tipo;
    }

    @Override
    public Object visit(Statement statement) throws Exception {

        if(statement instanceof AssignOp){
            ((AssignOp) statement).accept(this);
        }
        if(statement instanceof FunCallOpStat){
            ((FunCallOpStat) statement).accept(this);
        }
        if(statement instanceof ForOp){
            ((ForOp) statement).accept(this);
        }
        if(statement instanceof IfStatOp){
            ((IfStatOp) statement).accept(this);
        }
        if(statement instanceof ReadOp){
            ((ReadOp) statement).accept(this);
        }
        if(statement instanceof WhileOp){
            ((WhileOp) statement).accept(this);
        }
        if(statement instanceof WriteOp){
            ((WriteOp) statement).accept(this);
        }


        return null;
    }

    @Override
    public Object visit(WhileOp whileOp) throws Exception {

        String condition= (String) whileOp.getExpr().accept(this);
        if (!condition.equals("boolean"))
            throw new Eccezioni.ConditionNotValid();

        //Entro nello scope
        currentScope=whileOp.getSymbolTable();
        whileOp.getBody().accept(this);
        //Esco dallo scope
        currentScope=whileOp.getSymbolTable().getFather();

        return null;
    }

    @Override
    public Object visit(WriteOp writeOp) throws Exception {

        for(Expr expr:writeOp.getListExpr()) {
            expr.accept(this);
        }
        return null;
    }

    @Override
    /**
     * Regola di inferenza:
     *  Gamma implica che l'operazione op1 tra l'espressione e1 e l'espressione e2 è di tipo tau se,
     *  gamma implica che l'espressione e1 è di tipo tau1,
     *  gamma implica che l'espressione e2 è di tipo tau2 e
     *  optype2(op2,tau1,tau2) è uguale a tau.
     *
     *  Tabella optype2: combinazioniAritOp, combinazioniStrOp, combinazioniBooleanOp, combinazioniRelOp
     */
    public Object visit(BinaryOp binaryOp) throws Exception {
        //Ottengo il tipo dell'espressione1
        String typeExpr1= (String) binaryOp.getExpr1().accept(this);
        //Ottengo il tipo dell'espressione2
        String typeExpr2= (String) binaryOp.getExpr2().accept(this);

        //Ottengo il tipo di operazione
        String typeOp=binaryOp.getTypeOp();
        if(typeOp.equals("AddOp") | typeOp.equals("DiffOp") | typeOp.equals("MulOp") | typeOp.equals("DivOp") |
                typeOp.equals("PowOp")){
            //Si tratta di un operazione aritmetica

            for (String[] combinazione:combinazioniAritOp) {
                if (typeExpr1.equals(combinazione[0]) && typeExpr2.equals(combinazione[1])){
                    binaryOp.setExprType(combinazione[2]);
                    return combinazione[2];
                }
            }

            throw new Eccezioni.ArithmeticOpError();
        }


        if(typeOp.equals("GTOp") | typeOp.equals("GEOp") | typeOp.equals("LTOp") | typeOp.equals("LEOp") |
                typeOp.equals("EQOp") | typeOp.equals("NEOp")){
            //Si tratta di un operazione relazionale
            for (String[] combinazione:combinazioniRelOp) {
                if (typeExpr1.equals(combinazione[0]) && typeExpr2.equals(combinazione[1])) {
                    binaryOp.setExprType(combinazione[2]);
                    return combinazione[2];
                }
            }
            throw new Eccezioni.RelationalOpError();
        }

        if(typeOp.equals("StrCatOp")){
            //Si tratta di un operazione su stringhe
            for (String[] combinazione:combinazioniStrOp) {
                if (typeExpr1.equals(combinazione[0]) && typeExpr2.equals(combinazione[1])) {
                    binaryOp.setExprType(combinazione[2]);
                    return combinazione[2];
                }
            }
            throw new Eccezioni.StringOpError();
        }

        if(typeOp.equals("AndOp") | typeOp.equals("OrOp")){
            //Si tratta di un operazione su stringhe
            for (String[] combinazione:combinazioniBooleanOp) {
                if (typeExpr1.equals(combinazione[0]) && typeExpr2.equals(combinazione[1])) {
                    binaryOp.setExprType(combinazione[2]);
                    return combinazione[2];
                }
            }

            throw new Eccezioni.BooleanOpError();
        }

        return new Eccezioni.BinaryOpNotValid();
    }

    @Override
    /**
     * Se il numero di parametri nella chiamata non coincide col numero di parametri
     * nella dichiarazione di funzione lancio l'errore CallFunNumParamError
     * Se il tipo di parametri nella chiamata non coincide col tipo dei parametri nella
     * dichiarazione di funzione lancio l'errore CallFunTypeParamError()
     *
     */
    public Object visit(FunCallOpExpr funCallOp) throws Exception {
        //Verifico che il numero di parametri nella chiamata coincide
        TableRow result=currentScope.lookup(funCallOp.getIdentifier().getLessema());
        if(result==null){
            throw new Eccezioni.NoDeclarationError("Funzione", funCallOp.getIdentifier().getLessema()); //La funzione non Ã¨ stata dichairata
        }else{
            FieldType.FieldTypeFunction dichiarazione =(FieldType.FieldTypeFunction) result.getType();
            ArrayList<String> inputParam=dichiarazione.getInputParam();
            String[] typeStream=result.getPropreties().split(",");
            int numeroParamteri=inputParam.size();
            int numeroParametriChiamata=0;
            if(funCallOp.getListExpr()!=null)
                numeroParametriChiamata=funCallOp.getListExpr().size();

            if(numeroParamteri!=numeroParametriChiamata){
                throw new Eccezioni.CallFunNumParamError(); //Il Numero di parametri non coincide
            }else{
                //Verifico che il tipo coincide
                for(int i=0;i<numeroParametriChiamata;i++){
                    Expr expr=(funCallOp.getListExpr().get(i));
                    //Controllo se ce qualche riduzione
                    String tipo= (String) expr.accept(this);
                    boolean isCompatibile=false;
                    for(String[] riduzione: compatibilita){
                        if(inputParam.get(i).equals(riduzione[0])&&tipo.equals(riduzione[1]))
                            isCompatibile=true;
                    }
                    if(!tipo.equals(inputParam.get(i))) {
                        throw new Eccezioni
                                .CallFunTypeParamError();
                    }else{
                        //Aggiungo lo stream
                        if (expr.getMode()==null)
                            expr.setMode(typeStream[i]);

                    }
                }
                if(dichiarazione.getOutputParam()!=null && dichiarazione.getOutputParam().size()>0) {
                    funCallOp.setExprType(dichiarazione.getOutputParam().get(0));
                    return dichiarazione.getOutputParam().get(0);
                }else
                    return null;
            }
        }

    }

    @Override
    public Object visit(ConstOp constOp) throws Exception {
        String type = constOp.getTypeConst();
        if (type.equals("boolean_const")) {
            constOp.setExprType("boolean");
            return "boolean";
        }
        if (type.equals("integer_const")) {
            constOp.setExprType("integer");
            return "integer";
        }
        if (type.equals("real_const")) {
            constOp.setExprType("float");
            return "float";
        }
        if (type.equals("string_const")) {
            constOp.setExprType("string");
            return "string";
        }
        if (type.equals("char_const")) {
            constOp.setExprType("char");
            return "char";
        }

        return null;
    }



    @Override
    public Object visit(Expr expr) throws Exception {
        String type = null;
        if(expr instanceof IdInitOp)
            type= (String) ((IdInitOp) expr).accept(this);
        if(expr instanceof ConstOp)
            type= (String) ((ConstOp) expr).accept(this);
        if(expr instanceof BinaryOp)
            type= (String) ((BinaryOp) expr).accept(this);
        if(expr instanceof UnaryOp)
            type= (String) ((UnaryOp) expr).accept(this);
        if(expr instanceof Identifier)
            type= (String) ((Identifier) expr).accept(this);
        if(expr instanceof FunCallOpExpr)
            type= (String) ((FunCallOpExpr) expr).accept(this);

        return type;
    }

    @Override
    public Object visit(Identifier identifier) throws Exception {

        TableRow result=currentScope.lookup(identifier.getLessema());
        if(result==null) {
            throw new Eccezioni.NoDeclarationError("Variabile", identifier.getLessema());
        }else{

            if(result.getType() instanceof FieldType.FieldTypeFunction)
                return ((FieldType.FieldTypeFunction) result.getType()).getOutputParam().get(0);
            else {
                identifier.setExprType(((FieldType.FieldTypeVar) result.getType()).getType());
                return ((FieldType.FieldTypeVar) result.getType()).getType();
            }

        }

    }

    @Override
    public Object visit(IdInitObbOp idInitObbOp) throws Exception {
        return null;
    }

    @Override
    public Object visit(IdInitOp idInitOp) throws Exception {
        String type=(String) idInitOp.getExpr().accept(this);
        return type;
    }

    @Override
    public Object visit(UnaryOp unaryOp) throws Exception {
        String typeExpr= (String) unaryOp.getExpr().accept(this);
        String typeOp=unaryOp.getType();
        if (typeOp.equals("UminusOp")){
            for(String[] combinazione: combinazioniMinus){
                if(typeExpr.equals(combinazione[0])) {
                    unaryOp.setExprType(combinazione[1]);
                    return combinazione[1];
                }
                throw new Eccezioni.MinusOpError();
            }
        }
        if (typeOp.equals("NotOp")){
            for(String[] combinazione: combinazioniNot){
                if(typeExpr.equals(combinazione[0])){
                    unaryOp.setExprType(combinazione[1]);
                    return combinazione[1];
                }
                throw new Eccezioni.NotOpError();
            }
        }

        return null;
    }





}
