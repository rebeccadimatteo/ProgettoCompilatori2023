package esercitazione5.visitor.semanticVisitor;



import esercitazione5.nodi_Gram.FunOp;
import esercitazione5.nodi_Gram.*;
import esercitazione5.nodi_Gram.ProgramOp;
import esercitazione5.nodi_Gram.VarDeclOp;
import esercitazione5.nodi_Gram.nodiExpr.*;
import esercitazione5.nodi_Gram.nodiExpr.Identifier;
import esercitazione5.nodi_Gram.statement.*;
import esercitazione5.table.FieldType;
import esercitazione5.table.SymbolTable;
import esercitazione5.table.TableRow;
import esercitazione5.utils.Eccezioni;
import esercitazione5.visitor.Visitor;

import java.util.ArrayList;
import java.util.Collection;

public class SemanticVisitorScope implements Visitor {
    private SymbolTable padre=null;

    @Override
    /**
     * Genero lo scope della root, inserendo variabili e funzioni
     */
    public Object visit(ProgramOp programOp) throws Exception {

        programOp.setSymbolTable(new SymbolTable());
        SymbolTable symbolTable=programOp.getSymbolTable();
        symbolTable.setScope("Root");
        symbolTable.setFather(null);
        padre=symbolTable;

        //Se sono presenti variabili le aggiungo allo scope
        if(programOp.getVarDeclList()!=null){
            ArrayList<TableRow> listaVar;
            for(VarDeclOp var:programOp.getVarDeclList()){
                listaVar= (ArrayList<TableRow>) var.accept(this);
                for(TableRow row :listaVar){
                    symbolTable.addRow(row);
                }
            }
        }


        //Se sono presenti funzioni le aggiungo allo scope
        if(programOp.getFunOpList()!=null){
            for(FunOp fun:programOp.getFunOpList()){
                String identificatore=fun.getIdentificatore().getLessema();
                FieldType.FieldTypeFunction typeField=new FieldType.FieldTypeFunction();
                String typeStream="";
                if(fun.getParams()!=null){
                    ArrayList<String[]> listaParametri=new ArrayList<String[]>();
                    for(ParDeclOp param: fun.getParams())
                        listaParametri.addAll((Collection<? extends String[]>) param.accept(this));

                    for(String[] parametro:listaParametri){
                        typeField.addInputParam(parametro[1]);
                        typeStream=typeStream+parametro[2]+",";
                    }
                }
                typeField.addOutputParam(fun.getType());
                symbolTable.addRow(new TableRow(identificatore, FunOp.class, typeField, typeStream));
            }
        }

        //Aggiungo la funzione main allo scope
        String identificatore=programOp.getMain().getIdentificatore().getLessema();
        FieldType.FieldTypeFunction typeField=new FieldType.FieldTypeFunction();
        String typeStream="";
        if(programOp.getMain().getParams()!=null){
            ArrayList<String[]> listaParametri=new ArrayList<String[]>();
            for(ParDeclOp param: programOp.getMain().getParams())
                listaParametri.addAll((Collection<? extends String[]>) param.accept(this));

            for(String[] parametro:listaParametri){
                typeField.addInputParam(parametro[1]);
                typeStream=typeStream+parametro[2]+",";
            }
        }

        if (typeStream.endsWith(","))
            typeStream=typeStream.substring(0,typeStream.length()-1);

        typeField.addOutputParam(programOp.getMain().getType());
        symbolTable.addRow(new TableRow(identificatore,FunOp.class,typeField,typeStream));


        //Riga da eliminare
        //programOp.getSymbolTable().toString();

        //Lancio la generazione degli scope per le funzioni
        if(programOp.getFunOpList()!=null) {
            for (FunOp fun : programOp.getFunOpList()) {
                padre=programOp.getSymbolTable();
                fun.accept(this);
            }
        }

        padre=programOp.getSymbolTable();
        programOp.getMain().accept(this);

        return null;
    }

    @Override
    /**
     * Genero una TableRow per ogni variabile
     */
    public Object visit(VarDeclOp varDecl) throws Exception {

        ArrayList<TableRow> listVar = new ArrayList<TableRow>();
        String identificatore = "";
        String tipo = "";

        for (Expr expr: varDecl.getExprList()) {
            if (expr instanceof Identifier){
                identificatore=((Identifier) expr).getLessema();
                tipo=varDecl.getType(); //Il tipo della variabile corrispone con quello della dichiarazione
            }
            if (expr instanceof IdInitOp) {
                identificatore=((IdInitOp) expr).getId().getLessema();
                tipo = varDecl.getType(); //Il tipo della variabile corrispone con quello della dichiarazione
            }
            if (expr instanceof IdInitObbOp) {
                identificatore = ((IdInitObbOp) expr).getId().getLessema();
                tipo = (String) ((IdInitObbOp) expr).getExpr().accept(this); //Il tipo viene inferito
                //Aggiorno il tipo nel nodo
                varDecl.setType(tipo);
            }
            listVar.add(new TableRow(identificatore, VarDeclOp.class, new FieldType.FieldTypeVar(tipo), ""));
        }

        return listVar;
    }

    @Override
    /**
     * Genero lo scope della funzione, aggiungendo i parametri
     */
    public Object visit(FunOp funOp) throws Exception {

        funOp.setSymbolTable(new SymbolTable());
        SymbolTable symbolTable=funOp.getSymbolTable();
        symbolTable.setFather(padre);
        symbolTable.setScope(funOp.getIdentificatore().getLessema());

        //Se sono presenti parametri li aggiungo allo scope
        if(funOp.getParams()!=null){
            ArrayList<String[]> listaParametri=new ArrayList<String[]>();
            for(ParDeclOp param: funOp.getParams()){
                listaParametri.addAll((Collection<? extends String[]>) param.accept(this));
            }

            for (String[] param:listaParametri)
                symbolTable.addRow(new TableRow(param[0],ParDeclOp.class,new FieldType.FieldTypeVar(param[1]),param[2]));
        }



        if(funOp.getBody()!=null){
            padre=funOp.getSymbolTable();
            funOp.getBody().accept(this);
        }



        return null;
    }

    @Override
    public Object visit(ParDeclOp parDeclOp) {

        ArrayList<String[]> listParametri=new ArrayList<>();
        for (Identifier id: parDeclOp.getIdList()){
            listParametri.add(new String[]{id.getLessema(), parDeclOp.getType(), parDeclOp.getTypeStream()});
        }

        return listParametri;
    }

    @Override
    /**
     * Aggiungo le variabili allo scope del body
     */
    public Object visit(BodyOp bodyOp) throws Exception {

        if(bodyOp.getListVar()!=null){
            ArrayList<TableRow> listaVar;
            for(VarDeclOp var:bodyOp.getListVar()){
                listaVar= (ArrayList<TableRow>) var.accept(this);
                for(TableRow row :listaVar){
                    padre.addRow(row);
                }
            }
        }

        //padre.toString();

        if(bodyOp.getListStatement()!=null){
            for (Statement stat:bodyOp.getListStatement()){
                if(stat instanceof WhileOp)
                    //Genero lo scope di While
                    ((WhileOp) stat).accept(this);
                if(stat instanceof ForOp)
                    //Genero lo scope di For
                    ((ForOp) stat).accept(this);
                //Genero lo scope di If
                if(stat instanceof IfStatOp)
                    ((IfStatOp) stat).accept(this);
            }
        }

        return null;
    }

    @Override
    public Object visit(AssignOp assignOp) {
        return null;
    }

    @Override
    public Object visit(FunCallOpStat callFunOpStat) {
        return null;
    }

    @Override
    //Genero la symbol table per il For
    public Object visit(ForOp forOp) throws Exception {

        forOp.setSymbolTable(new SymbolTable());
        SymbolTable symbolTable=forOp.getSymbolTable();
        symbolTable.setScope("For");
        symbolTable.setFather(padre);

        String identificatore=forOp.getId().getId().getLessema();
        symbolTable.addRow(new TableRow(identificatore,VarDeclOp.class,new FieldType.FieldTypeVar("integer"),""));

        if(forOp.getBodyOp()!=null) {
            padre = forOp.getSymbolTable();
            forOp.getBodyOp().accept(this);
        }

        return null;
    }

    @Override
    //Genero la symbol table per l'if
    public Object visit(IfStatOp ifStatOp) throws Exception {

        ifStatOp.setSymbolTableThen(new SymbolTable());
        SymbolTable symbolTableThen=ifStatOp.getSymbolTableThen();
        symbolTableThen.setScope("If-Then");
        symbolTableThen.setFather(padre);
        ifStatOp.setSymbolTableElse(new SymbolTable());
        SymbolTable symbolTableElse=ifStatOp.getSymbolTableElse();
        symbolTableElse.setScope("If-Else");
        symbolTableElse.setFather(padre);


        if(ifStatOp.getBodyThen()!=null) {
            padre = ifStatOp.getSymbolTableThen();
            ifStatOp.getBodyThen().accept(this);
        }

        //Symbol Table Else
        if(ifStatOp.getBodyElse()!=null) {
            padre=ifStatOp.getSymbolTableElse();
            ifStatOp.getBodyElse().accept(this);
        }

        return null;
    }

    @Override
    public Object visit(ReadOp readOp) {
        return null;
    }

    @Override
    public Object visit(ReturnOp returnOp) {
        return null;
    }

    @Override
    public Object visit(Statement statement) {
        return null;
    }

    @Override
    //Genero la symbol table per il while
    public Object visit(WhileOp whileOp) throws Exception {

        whileOp.setSymbolTable(new SymbolTable());
        SymbolTable symbolTable=whileOp.getSymbolTable();
        symbolTable.setScope("While");
        symbolTable.setFather(padre);


        if(whileOp.getBody()!=null) {
            padre = whileOp.getSymbolTable();
            whileOp.getBody().accept(this);
        }

        return null;
    }

    @Override
    public Object visit(WriteOp writeOp) {
        return null;
    }

    @Override
    public Object visit(BinaryOp aritAndRelOp) throws Exception {

        aritAndRelOp.getExpr1().accept(this);
        aritAndRelOp.getExpr2().accept(this);
        return null;
    }

    @Override
    public Object visit(FunCallOpExpr callFunOpExpr) {
        return null;
    }

    @Override
    public Object visit(ConstOp constOp) {
        String type = constOp.getTypeConst();
        if (type.equals("boolean_const"))
            return "boolean";
        if (type.equals("integer_const"))
            return "integer";
        if (type.equals("real_const"))
            return "float";
        if (type.equals("string_const"))
            return "string";
        if (type.equals("char_const"))
            return "char";
        return null;
    }

    @Override
    public Object visit(Expr expr) throws Exception {

        if(expr instanceof IdInitOp)
            ((IdInitOp) expr).accept(this);
        if(expr instanceof ConstOp)
            if(expr instanceof BinaryOp)
                ((BinaryOp) expr).accept(this);
        if(expr instanceof UnaryOp)
            ((UnaryOp) expr).accept(this);
        if(expr instanceof Identifier)
            ((Identifier) expr).accept(this);

        return null;
    }

    @Override
    public Object visit(Identifier identifier) throws Exception {

        if(padre.lookup(identifier.getLessema())==null)
            throw new Eccezioni.NoDeclarationError("Variabile", identifier.getLessema());

        return null;
    }

    @Override
    public Object visit(IdInitObbOp idInitObbOp) {
        return null;
    }

    @Override
    public Object visit(IdInitOp idInitOp) throws Exception {

        idInitOp.getExpr().accept(this);

        return null;
    }

    @Override
    public Object visit(UnaryOp unaryOp) throws Exception {

        unaryOp.getExpr().accept(this);
        return null;
    }
}
