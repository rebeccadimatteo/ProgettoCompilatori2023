package esercitazione5.visitor;

import esercitazione5.nodi_Gram.*;
import esercitazione5.nodi_Gram.nodiExpr.*;
import esercitazione5.nodi_Gram.statement.*;

//metodi che permettono di visitare tutti i nodi dell'albero sintattico
public interface Visitor {


    public Object visit(ProgramOp programOp) throws Exception;
    public Object visit(VarDeclOp varDecl) throws Exception;
    public Object visit(FunOp funOp) throws Exception;
    public Object visit(ParDeclOp parDeclOp) throws Exception;
    public Object visit(BodyOp bodyOp) throws Exception;
    public Object visit(AssignOp assignOp) throws Exception;
    public Object visit(FunCallOpStat funcallOpStat) throws Exception;
    public Object visit(ForOp forOp) throws Exception;
    public Object visit(IfStatOp ifStatOp) throws Exception;
    public Object visit(ReadOp readOp) throws Exception;
    public Object visit(ReturnOp returnOp) throws Exception;
    public Object visit(Statement statement) throws Exception;
    public Object visit(WhileOp whileOp) throws Exception;
    public Object visit(WriteOp writeOp) throws Exception;
    public Object visit(BinaryOp binaryOp) throws Exception;
    public Object visit(FunCallOpExpr funCallOpExpr) throws Exception;
    public Object visit(ConstOp constOp) throws Exception;
    public Object visit(Expr expr) throws Exception;
    public Object visit(Identifier identifier) throws Exception;
    public Object visit(IdInitObbOp idInitObbOp) throws Exception;
    public Object visit(IdInitOp idInitOp) throws Exception;
    public Object visit(UnaryOp unaryOp) throws Exception;
}
