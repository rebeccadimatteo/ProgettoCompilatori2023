package esercitazione5.nodi_Gram.statement;


import esercitazione5.nodi_Gram.BodyOp;
import esercitazione5.nodi_Gram.nodiExpr.ConstOp;
import esercitazione5.nodi_Gram.nodiExpr.IdInitOp;
import esercitazione5.table.SymbolTable;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;


public class ForOp extends Statement implements Visitable {

    private IdInitOp id;//inizializzaione
    private ConstOp cons; //condizione
    private BodyOp bodyOp;
    private SymbolTable symbolTable;

    public ForOp(IdInitOp id,ConstOp cons,BodyOp bodyOp){
        super("ForOp");
        super.add(id);
        super.add(cons);
        super.add(bodyOp);

        this.id=id;
        this.cons=cons;
        this.bodyOp=bodyOp;
    }

    public IdInitOp getId() {
        return id;
    }

    public ConstOp getCons() {
        return cons;
    }

    public BodyOp getBodyOp() {
        return bodyOp;
    }

    public String toString() {return super.toString();}

    public void setSymbolTable(SymbolTable symbolTable){this.symbolTable=symbolTable;}

    public SymbolTable getSymbolTable(){return this.symbolTable;}

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}