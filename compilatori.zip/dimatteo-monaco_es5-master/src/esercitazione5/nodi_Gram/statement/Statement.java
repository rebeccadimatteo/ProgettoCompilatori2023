package esercitazione5.nodi_Gram.statement;

import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class Statement extends DefaultMutableTreeNode implements Visitable {

    public Statement(String nodeName){
        super(nodeName);
    }

    public String toString() { return super.toString(); }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
