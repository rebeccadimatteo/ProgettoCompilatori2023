package esercitazione5.nodi_Gram.statement;


import esercitazione5.nodi_Gram.BodyOp;
import esercitazione5.nodi_Gram.nodiExpr.Expr;
import esercitazione5.table.SymbolTable;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

public class IfStatOp extends Statement implements Visitable {

    private Expr expr; // condizione
    private BodyOp bodyThen; // Body
    private BodyOp bodyElse; //alternativa
    private SymbolTable symbolTableThen; //scope diverso

    private SymbolTable symbolTableElse;// scope diverso
    public IfStatOp(Expr expr, BodyOp bodyThen, BodyOp bodyElse){
        super("IfStatOp");
        super.add(expr);
        super.add(bodyThen);
        super.add(bodyElse);

        this.expr=expr;
        this.bodyThen=bodyThen;
        this.bodyElse=bodyElse;
    }

    public IfStatOp(Expr expr, BodyOp bodyThen){
        super("IfStatOp");
        super.add(expr);
        super.add(bodyThen);

        this.expr=expr;
        this.bodyElse = null;
        this.bodyThen = bodyThen;
    }

    public Expr getExpr() {
        return expr;
    }

    public BodyOp getBodyThen() {
        return bodyThen;
    }

    public BodyOp getBodyElse() {
        return bodyElse;
    }

    public SymbolTable getSymbolTableThen() {return this.symbolTableThen;}

    public void setSymbolTableThen(SymbolTable symbolTable) {this.symbolTableThen=symbolTable;}

    public SymbolTable getSymbolTableElse() {return this.symbolTableElse;}

    public void setSymbolTableElse(SymbolTable symbolTable) {this.symbolTableElse=symbolTable;}

    public String toString() {return super.toString();}

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
