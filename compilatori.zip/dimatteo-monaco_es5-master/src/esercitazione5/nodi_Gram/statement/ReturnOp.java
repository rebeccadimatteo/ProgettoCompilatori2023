package esercitazione5.nodi_Gram.statement;


import esercitazione5.nodi_Gram.nodiExpr.Expr;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

public class ReturnOp extends Statement implements Visitable {

    private Expr expr;

    public ReturnOp(){
        super("ReturnOp");
        this.expr=null;
    }

    public ReturnOp(Expr expr){
        super("ReturnOp");
        super.add(expr);
        this.expr=expr;
    }

    public Expr getExpr() {
        return expr;
    }

    public String toString() {return super.toString();}

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
