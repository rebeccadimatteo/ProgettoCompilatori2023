package esercitazione5.nodi_Gram.statement;


import esercitazione5.nodi_Gram.BodyOp;
import esercitazione5.nodi_Gram.nodiExpr.Expr;
import esercitazione5.table.SymbolTable;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

public class WhileOp extends Statement implements Visitable {


    private Expr expr; //condizione
    private BodyOp body; //body


    private SymbolTable symbolTable; //scope diverso

    public WhileOp(Expr expr, BodyOp body){
        super("WhileOp");
        super.add(expr);
        super.add(body);

        this.expr=expr;
        this.body=body;
    }

    public Expr getExpr() {
        return expr;
    }

    public BodyOp getBody() {
        return body;
    }

    public void setSymbolTable(SymbolTable symbolTable) {this.symbolTable=symbolTable;}

    public SymbolTable getSymbolTable() {return this.symbolTable;}

    public String toString() {return super.toString();}



    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
