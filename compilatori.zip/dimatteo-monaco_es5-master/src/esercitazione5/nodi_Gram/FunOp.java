package esercitazione5.nodi_Gram;


import esercitazione5.nodi_Gram.nodiExpr.Identifier;
import esercitazione5.table.SymbolTable;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

//Rappresenta una funzione  che può avere identificatori-parametri-tipo-body
public class FunOp extends DefaultMutableTreeNode implements Visitable {

    private Identifier identificatore; //nome della funzione
    private ArrayList<ParDeclOp> params; //parametri
    private String type; //tipo
    private BodyOp body; //body
    private SymbolTable symbolTable; //tabella dei simboli nuovo scope per ogni funzione



    public FunOp(Identifier identificatore, ArrayList<ParDeclOp> params, String type, BodyOp body){

        super("FunOp"); //crea nodo

        super.add(identificatore); //aggiunge figlio con nome della funzione
        for (ParDeclOp parDecl: params) //aggiunge figlio con lista paraemtri
            super.add(parDecl);
        super.add(new DefaultMutableTreeNode(type)); // aggiunge un altro nodo con il tipo
        super.add(body); // non fa il nuovo nodo perchè Body gia lo crea la classe


        this.identificatore=identificatore;
        this.params=params;
        this.type=type;
        this.body=body;
    }

    //Costruttore per funzione che non ha parametri
    public FunOp(Identifier identificatore, String type, BodyOp body){

        super("FunOp");

        super.add(identificatore);
        super.add(new DefaultMutableTreeNode(type));
        super.add(body);


        this.identificatore=identificatore;
        this.params=null;
        this.type=type;
        this.body=body;
    }

    public Identifier getIdentificatore() { return identificatore; }

    public ArrayList<ParDeclOp> getParams() { return params; }

    public String getType() { return type; }

    public BodyOp getBody() { return body; }



    public void addParam(ParDeclOp param) {
        super.add(param);
        this.params.add(param);
    }

    public void addsParams(ArrayList<ParDeclOp> params) {
        for (ParDeclOp param: params)
            super.add(param);
        this.params.addAll(params);
    }
    public void setSymbolTable(SymbolTable symbolTable){this.symbolTable=symbolTable;}

    public SymbolTable getSymbolTable(){return this.symbolTable;}
    public String toString(){ return super.toString(); }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
