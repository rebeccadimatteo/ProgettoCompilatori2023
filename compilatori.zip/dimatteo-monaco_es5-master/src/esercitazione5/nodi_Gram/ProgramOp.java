package esercitazione5.nodi_Gram;


import esercitazione5.nodi_Gram.nodiExpr.Identifier;
import esercitazione5.table.SymbolTable;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;
//programma intero con una serie di dichiarazioni di variabili
// funzioni almeno un main scope delle simbol table
public class ProgramOp extends DefaultMutableTreeNode implements Visitable {

    private ArrayList<VarDeclOp> varDeclList;
    private ArrayList<FunOp> funOpList;
    private FunOp main;
    private SymbolTable symbolTable;




    public ProgramOp(ArrayList<VarDeclOp> varDeclList, FunOp main, ArrayList<FunOp> funOpList){
        super("ProgramOp");  //nome del nodo
        //aggiunge all'albero lista variabili e funzioni
        for (VarDeclOp varDecl: varDeclList)
            super.add(varDecl);

        for (FunOp funOp: funOpList)
            super.add(funOp);


//crea nuovo nodo per il main
        DefaultMutableTreeNode mainNode=new DefaultMutableTreeNode("Main");
        Identifier idMain=main.getIdentificatore(); //prende id del main start:
        ArrayList<ParDeclOp> paramsMain=main.getParams(); //prende parametri
        String  typeMain=main.getType(); //body del main
        BodyOp bodyMain=main.getBody(); //crea nodo main id, param e body
        mainNode.add(idMain);
        if (paramsMain!=null)
            for(ParDeclOp param:paramsMain)
                mainNode.add(param);
        mainNode.add(new DefaultMutableTreeNode(typeMain));
        mainNode.add(bodyMain);

        super.add(mainNode); //aggiunge all'albero


        this.varDeclList = varDeclList;
        this.funOpList = funOpList;
        this.main=main;

    }
//altro costruttore in cui non ci sono variabili globali
    public ProgramOp(FunOp main, ArrayList<FunOp> funOpList){

        super("ProgramOp");

        for (FunOp funOp: funOpList)
            super.add(funOp);

        super.add(main);

        this.varDeclList =null;
        this.funOpList = funOpList;
        this.main=main;

    }
// aggiunge nuove variabili
    public void addVarDec(VarDeclOp varDec) {
        super.add(varDec);
        this.varDeclList.add(varDec);
    }
    // aggiunge nuove funzioni
    public void addFunOp(FunOp funOp) {
        super.add(funOp);
        this.funOpList.add(funOp);
    }
//aggiunge lista variabili
    public void addsVarDec(ArrayList<VarDeclOp> varDecList) {
        for (VarDeclOp varDecOp: varDecList) {
            super.add(varDecOp);
            this.varDeclList.add(varDecOp);
        }
    }
//aggiunge lista di funzioni
    public void addsFunOp(ArrayList<FunOp> funOpList) {
        for (FunOp funOp: funOpList) {
            super.add(funOp);
            this.funOpList.add(funOp);
        }
    }

    public ArrayList<VarDeclOp> getVarDeclList() { return this.varDeclList; }
    public FunOp getMain() { return main; }

    public ArrayList<FunOp> getFunOpList() {return this.funOpList;}

    public void setSymbolTable(SymbolTable symbolTable){this.symbolTable=symbolTable;}

    public SymbolTable getSymbolTable(){return this.symbolTable;}


    public String toString() {return super.toString();}


    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }

}
