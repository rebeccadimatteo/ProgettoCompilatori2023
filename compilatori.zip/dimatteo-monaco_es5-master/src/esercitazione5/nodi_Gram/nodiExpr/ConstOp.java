package esercitazione5.nodi_Gram.nodiExpr;

import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

public class ConstOp extends Expr implements Visitable {

    private String lessema;
    private String typeConst;

    public ConstOp(String typeConst, String lessema){
        super(typeConst+": "+lessema);
        this.typeConst=typeConst;
        this.lessema=lessema;
    }

    public String getLessema() {
        return lessema;
    }

    public String getTypeConst() {
        return typeConst;
    }

    public String toString() {return super.toString();}

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
