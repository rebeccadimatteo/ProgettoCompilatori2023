package esercitazione5.nodi_Gram.nodiExpr;

import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

public class Identifier extends Expr implements Visitable {

    private String lessema;

    public Identifier(String lessema){
        super("ID: "+lessema);
        this.lessema=lessema;
    }

    public String getLessema(){ return this.lessema; }

    public void setLessema(String lessema) {this.lessema=lessema;}
    public void setTipoEspressione(String type) {super.setExprType(type);}

    public String getTipoEspressione() {return super.getExprType();}

    public String toString() {return super.toString();}

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
