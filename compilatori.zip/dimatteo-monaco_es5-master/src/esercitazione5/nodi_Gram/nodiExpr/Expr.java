package esercitazione5.nodi_Gram.nodiExpr;

import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;


//E' una costante
public class Expr extends DefaultMutableTreeNode implements Visitable {

    private String mode;
    private String exprType;

    public Expr(String nodeName) {
        super(nodeName);
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getExprType() {
        return exprType;
    }

    public void setExprType(String exprType) {
        this.exprType = exprType;
    }

    public String toString() {return super.toString();}

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}