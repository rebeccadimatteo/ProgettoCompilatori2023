package esercitazione5.table;

public class TableRow {
    //lessema
    private String symbol;
    //quale nodo è
    private Object node;
    //i tipi
    private FieldType type;

    private String propreties;

    public TableRow(String symbol, Object node, FieldType type, String propreties){
        this.symbol=symbol;
        this.node=node;
        this.type=type;
        this.propreties=propreties;

    }

    public String getSymbol() {
        return symbol;
    }

    public Object getKind() {
        return node;
    }

    public FieldType getType() {
        return type;
    }

    public String getPropreties() {
        return propreties;
    }

    @Override
    public String toString() {
        String typeString;
        if (type.getClass() == FieldType.FieldTypeFunction.class)
            typeString = ((FieldType.FieldTypeFunction) type).toString();
        else
            typeString = ((FieldType.FieldTypeVar) type).toString();
        return "Symbol: " + symbol + ", Kind: " + node.toString() + ", Type: " + typeString + ", Propreties: " + propreties;

    }
}
