package esercitazione5.table;

import java.util.ArrayList;

public class FieldType {

    public static class FieldTypeFunction extends FieldType{
        private ArrayList<String> inputParam;
        private ArrayList<String> outputParam;

        public FieldTypeFunction() {
            inputParam=new ArrayList<String>();
            outputParam=new ArrayList<String>();
        }

        public FieldTypeFunction (ArrayList<String> inputParam, ArrayList<String> outputParam){
            this.inputParam=inputParam;
            this.outputParam=outputParam;
        }

        public ArrayList<String> getInputParam() {
            return inputParam;
        }

        public void addInputParam(String inputParm) {
            this.inputParam.add(inputParm);
        }

        public void addsListInputParam(ArrayList<String> listInputParam) {
            this.inputParam.addAll(listInputParam);
        }

        public ArrayList<String> getOutputParam() {
            return outputParam;
        }

        public void addOutputParam(String outputParm) {
            this.outputParam.add(outputParm);
        }

        public void addsListOutputParam(ArrayList<String> listOutputParm) {
            this.outputParam.addAll(listOutputParm);
        }

        public String toString() {
            String str;
            if (inputParam==null || inputParam.size()==0)
                str="->"+outputParam.toString();
            else
                str=inputParam.toString()+"->"+outputParam.toString();

            return str;
        }
    }

    public static class FieldTypeVar extends FieldType {
        private String type;

        public FieldTypeVar(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String toString() {
            return type;
        }
    }
}
