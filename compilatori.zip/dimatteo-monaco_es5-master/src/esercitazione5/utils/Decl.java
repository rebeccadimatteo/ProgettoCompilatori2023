package esercitazione5.utils;


import esercitazione5.nodi_Gram.FunOp;
import esercitazione5.nodi_Gram.VarDeclOp;
import esercitazione5.visitor.Visitable;
import esercitazione5.visitor.Visitor;

import java.util.ArrayList;
//Dichiazioni
public class Decl  {

    private ArrayList<VarDeclOp> varDeclList;
    private ArrayList<FunOp> funOpList;

    public Decl(){
        this.varDeclList=new ArrayList<VarDeclOp>();
        this.funOpList=new ArrayList<FunOp>();
    }

    public Decl(ArrayList<VarDeclOp> varDeclList, ArrayList<FunOp> funOpList){
        this.varDeclList=new ArrayList<VarDeclOp>();
        this.funOpList=new ArrayList<FunOp>();
        this.varDeclList.addAll(varDeclList);
        this.funOpList.addAll(funOpList);
    }

    public void addVarDecl(VarDeclOp varDecl) {this.varDeclList.add(varDecl);}
    public void addsVarDeclList(ArrayList<VarDeclOp> varDeclList) {this.varDeclList.addAll(varDeclList);}

    public void addFunOp(FunOp funOp) {this.funOpList.add(funOp);}
    public void addsFunOpList(ArrayList<FunOp> funOpList) {this.funOpList.addAll(funOpList);}


    public ArrayList<VarDeclOp> getVarDeclList() {return this.varDeclList;}
    public ArrayList<FunOp> getFunOpList() {return this.funOpList;}




}
