package esercitazione5;


import esercitazione5.nodi_Gram.ProgramOp;
import esercitazione5.visitor.semanticVisitor.SemanticVisitorScope;
import esercitazione5.visitor.semanticVisitor.SemanticVisitorType;
import esercitazione5.visitor.semanticVisitor.VisitorCodeGeneration;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.io.*;

public class Compilatore {
    public static void main(String[] args) throws FileNotFoundException {
        JTree tree;
        String separator = File.separator;
        File input = new File(args[0]);
        String[] slashSplit = args[0].split("/");
        String fullName = slashSplit[slashSplit.length-1];
         String fileName = fullName.split(".txt")[0];
         parser p = new parser(new Lexer(new FileReader(input)));
        try {
            DefaultMutableTreeNode root = (DefaultMutableTreeNode) p.parse().value;
            //Genero le symbol table
            try {
                ((ProgramOp) root).accept(new SemanticVisitorScope());
                ((ProgramOp) root).accept(new SemanticVisitorType());
                VisitorCodeGeneration.FILE_NAME = fileName + ".c";
                ((ProgramOp) root).accept(new VisitorCodeGeneration());
            } catch (Exception e) {
                System.out.println(fileName + ".txt");
            }
            /*
            ProcessBuilder builder = new ProcessBuilder(
                    "cmd", "/c", "cd test_files && cd c_out && gcc " + VisitorCodeGeneration.FILE_NAME);
            builder.redirectErrorStream(true);
            Process process = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
            builder = new ProcessBuilder(
                    "cmd", "/c", "cd test_files && cd c_out && start a.exe");
            builder.redirectErrorStream(true);
            process = builder.start();
            r = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while (true) {
                line = r.readLine();
                if (line == null) {
                    break;
                }
                System.out.println(line);
            }
*/
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }
}