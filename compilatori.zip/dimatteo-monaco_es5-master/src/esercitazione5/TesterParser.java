package esercitazione5;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class TesterParser {/*
    public static void main(String[] args) throws FileNotFoundException {
        JTree tree;
        File input = new File(
                System.getProperty("user.dir") + args[0]);
        parser p = new parser(new Lexer(new FileReader(input)));

        try {
            DefaultMutableTreeNode root = (DefaultMutableTreeNode) p.parse().value;
            tree=new JTree(root);

            JFrame framePannello=new JFrame();
            framePannello.setSize(400, 400);
            JScrollPane treeView = new JScrollPane(tree);
            framePannello.add(treeView);
            framePannello.setVisible(true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }*/
}