package esercitazione5;

import java_cup.runtime.Symbol;

import java.io.FileNotFoundException;

public class TesterLexer {/*

    public static void main(String[] args) throws FileNotFoundException {
        Lexer lexicalAnalyzer = new Lexer(new java.io.FileReader(args[0]));

        Symbol token;
        try {
            while ((token = lexicalAnalyzer.next_token()) != null) {
                if(token.sym == Token.EOF) { //Se il file è terminato
                    break;
                }
                if(token.value == null) { //Se il token appartiene alle KeyWords
                    System.out.println("<" + Token.terminalNames[token.sym] + ">");
                }else{ //Se è presente un valore lo stampa insieme al Token riconosciuto
                    System.out.println("<"+ Token.terminalNames[token.sym]+"," +token.value+">");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: Parsing Ended");
        }

    }*/
}

